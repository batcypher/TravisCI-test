class Calculator:
    
    def addition(self,x,y):
        added = x + y
        return added
        
    def subtraction(self,x,y):
        sub = x - y
        return sub

    def multiplication(self,x,y):
        mult = x * y
        return mult

    def division(self,x,y):
        div = x / y
        return div
